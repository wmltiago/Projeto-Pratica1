

function validaForm(){
           d = document.cadastro;
           //validar nome
           if (d.nome.value == ""){
                     alert("O campo NOME  deve ser preenchido!");
                     d.nome.style.backgroundColor="#87CEEB";
                     d.nome.style.color="#000000";
                    d.nome.focus();
                     return false;
           }
		   //validar CPF
		   if(d.cpf.value== ""){
					alert("O campo CPF deve ser preenchido!");
					d.cpf.style.backgroundColor="#87CEEB";
					d.cpf.style.color="#ffffff";
					d.cpf.focus();
					return false;
		   
		   }
		   // VALIDAR TURNO
		  
	 
		   if(d.rg.value == ""){
				alert("O campo RG deve ser preenchido!");
				d.rg.style.backgroundColor="#87CEEB";
				d.rg.style.color="#000000";
				d.rg.focus();
				return false;
		   }
		   
           //validar user         
                    
         /*  if (d.email.value == ""){
                   alert("O campo EMAIL  deve ser preenchido!");
                   d.email.style.backgroundColor="#87CEEB";
                   d.email.style.color="#ffffff";
                   d.email.focus();
                   return false;
         }
         //validar email(verificao de endereco eletrônico)
         parte1 = d.email.value.indexOf("@");
         parte3 = d.email.value.length;
         if (!(parte1 >= 3 && parte3 >= 9)) {
                   alert ("O campo EMAIL  deve ser conter um endereco eletronico!");
                   d.email.style.backgroundColor="red";
                   d.email.style.color="#ffffff";
                   d.email.focus();
                    
                   return false; 
         }if (d.mensagem.value == ""){
                     alert("Digite nos a mensagem!");
                     d.mensagem.style.backgroundColor="#87CEEB";
                     d.mensagem.style.color="#ffffff";
                     return false;
                     d.conheceu.focus();
           }
document.cadastro.submit(); */
         
}

function validaRealizarMatricula(){                //VALIDAÇÃO DA PAG "REALIZAR MATRICULA"
	
	
	var turno = document.getElementsByName("turno"); 
	 if (turno[0].checked == false && turno[1].checked ==false){
	 alert("Marque o TURNO do aluno!!");
	 turno[0].focus();
	 return false;
	 }
	 var inputSemestre = document.getElementById("semestre");
	 if(semestre.value == ""){
		 alert("Diga qual SEMESTRE o aluno está!");
		 semestre.style.backgroundColor="#87CEEB";
		 semestre.style.color="000000";
		 semestre.focus();
		 return false;
	 }
	 	 return true;
}


function validaRegistrarFaltas(){                      //VALIDAÇÃO DA PAG "REGISTRAR FALTAS"
	var alunos = document.getElementById("aluno");
	if(alunos.value== ""){
		alert("Selecione um ALUNO!");
		alunos.focus();
		return false;
	}
	var  faltas = document.getElementById("faltas");
		 if(faltas.value == ""){
			 alert("Preencha as FALTAS do aluno!");
			 faltas.focus();
		                      return false;
           }
	var disciplinas = document.getElementById("disciplina");
	if(disciplinas.value == ""){
		alert("Escolha uma DISCIPLINA!");
		disciplinas.focus();
		return false;
	}
		   
	return true;
	
		}
		
function validaRegistrarNotas(){                           //VALIDAÇÃO DA PAG "REGISTRAR NOTAS"
	var aluno = document.getElementById("alunoN");
	if (aluno.value == ""){
		alert("Selecione um ALUNO!");
		aluno.focus();
		return false;
	}
	var disciplina = document.getElementById("disciplinaN");
	if(disciplina.value == ""){
		alert("Escolha uma DISCIPLINA!");
		disciplina.focus();
		return false;
	}
	var unidade = document.getElementsByName("unidade");
	if(unidade[0].checked == false && unidade[1].checked == false){
		alert("Escolha a UNIDADE!");
		unidade[0].focus();
		return false;
	}
	var nota = document.getElementById("nota");
	if(nota.value == ""){
		alert("Insira a NOTA!");
		nota.focus();
		return false;
	}
	return true;		
}

function validarProjeto(){                   //VALIDAÇÃO DA PAG "CADASTRAR PROJETO PESQUISA"
	var professor = document.getElementById("prof");
	if(prof.value == ""){
		alert("Escolha um PROFESSOR !");
		professor.focus();
		return false;
	}
	var titulo = document.getElementById("tituloProjeto");
	if(titulo.value == ""){
	alert("Insira o TÍTULO DO PROJETO !");
	titulo.focus();
	return false;
	}
	return true;
	
	
}